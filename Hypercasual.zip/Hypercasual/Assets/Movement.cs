using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float startSpeed = 5f;
    public float maxSpeed = 2000f;
    public float acceleration = 2f;
    public float turnSpeed = 100f;

    public float nitroMultiplier = 2f;
    public ParticleSystem nitroEffect; // Assign in Inspector

    public Camera mainCamera;
    public float shakeIntensity = 0.2f;
    public float shakeDuration = 0.5f;

    public ParticleSystem crashEffect; // <-- Optional crash explosion effect

    private Rigidbody rb;
    private float horizontalInput;
    private float currentSpeed;
    private bool isNitroActive = false;
    private Vector3 originalCameraPosition;
    private float shakeTimer = 0f;
    private bool isCrashed = false; // <-- New flag

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
            rb.useGravity = false;
        }
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

        currentSpeed = startSpeed;

        if (mainCamera == null)
        {
            mainCamera = Camera.main;
        }
        originalCameraPosition = mainCamera.transform.localPosition;
    }

    void Update()
    {
        if (isCrashed) return; // If crashed, disable input

        // Get player input for turning
        horizontalInput = Input.GetAxis("Horizontal");

        // Handle Nitro Hold Logic
        if (Input.GetKey(KeyCode.Space))
        {
            if (!isNitroActive)
            {
                ActivateNitro();
            }
        }
        else
        {
            if (isNitroActive)
            {
                DeactivateNitro();
            }
        }
    }

    void FixedUpdate()
    {
        if (isCrashed) return; // If crashed, stop controlling

        // Gradually increase speed
        currentSpeed += acceleration * Time.fixedDeltaTime;
        currentSpeed = Mathf.Min(currentSpeed, maxSpeed);

        // Calculate final movement speed
        float finalSpeed = currentSpeed;
        if (isNitroActive)
        {
            finalSpeed *= nitroMultiplier;
        }

        // Always move forward
        Vector3 moveDirection = transform.forward * finalSpeed * Time.fixedDeltaTime;
        rb.MovePosition(rb.position + moveDirection);

        // Steer based on input
        float turn = horizontalInput * turnSpeed * Time.fixedDeltaTime;
        Quaternion turnRotation = Quaternion.Euler(0f, turn, 0f);
        rb.MoveRotation(rb.rotation * turnRotation);

        // Handle screen shake
        if (shakeTimer > 0)
        {
            shakeTimer -= Time.fixedDeltaTime;
            mainCamera.transform.localPosition = originalCameraPosition + Random.insideUnitSphere * shakeIntensity;
        }
        else
        {
            mainCamera.transform.localPosition = originalCameraPosition;
        }
    }

    void ActivateNitro()
    {
        isNitroActive = true;
        shakeTimer = shakeDuration;

        if (nitroEffect != null)
        {
            nitroEffect.Play();
        }
    }

    void DeactivateNitro()
    {
        isNitroActive = false;

        if (nitroEffect != null)
        {
            nitroEffect.Stop();
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (!collision.gameObject.CompareTag("Ground") && !isCrashed)
        {
            StartCoroutine(HandleCrash());
        }
    }

    IEnumerator HandleCrash()
    {
        isCrashed = true;
        rb.constraints = RigidbodyConstraints.None; // Allow wild rotation

        if (crashEffect != null)
        {
            crashEffect.transform.position = transform.position;
            crashEffect.Play();
        }

        // Add random torque for spin out
        rb.AddTorque(Random.onUnitSphere * 500f);

        yield return new WaitForSeconds(2f); // Crash animation duration

        Destroy(gameObject);
    }
}
