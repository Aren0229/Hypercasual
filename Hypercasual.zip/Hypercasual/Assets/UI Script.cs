using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public GameObject mainMenuPanel; // Assign the menu panel with buttons
    public PlayerMovement playerMovement; // Drag your player GameObject here in Inspector

    public void OnNewGamePressed()
    {
        mainMenuPanel.SetActive(false); // Hide UI
        playerMovement.gameStarted = true; // Start the game
    }
}
